// scripts/sheets/locationSheet.mjs
import { MAP_LOCATIONS, LOCATION_TYPES } from "../mapLocations.mjs";

export class EfdiLocationSheet extends ItemSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["efdi", "sheet", "item", "location"],
      template: "systems/escape-from-dino-island/templates/items/location-sheet.hbs",
      width: 400,
      height: 320,
      resizable: false
    });
  }

  async getData() {
    const data = await super.getData();
    const locationDef = MAP_LOCATIONS.find(l => l.id === this.item.system.locationType);
    return {
      ...data,
      locationDef,
      locationTypes: LOCATION_TYPES
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
  }
}
