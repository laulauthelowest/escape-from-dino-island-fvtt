// scripts/sheets/dinosaurSheet.mjs
import { DINO_TYPES, DINO_GIMMICKS } from "../dinoData.mjs";

export class EfdiDinosaurSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["efdi", "sheet", "actor", "dinosaur"],
      template: "systems/escape-from-dino-island/templates/actors/dinosaur-sheet.hbs",
      width: 580,
      height: 560,
      resizable: true
    });
  }

  async getData() {
    const data = await super.getData();
    const system = this.actor.system;

    // Alle Dino-Typen für Dropdown
    const dinoTypeOptions = Object.entries(DINO_TYPES).map(([id, d]) => ({
      id,
      label: d.label
    }));

    // Wenn Typ gewählt: Vorschlagsdaten laden
    const selectedType = system.dinoType ?? "";
    const typeDef = DINO_TYPES[selectedType] ?? null;

    // Moves: aus system laden, Fallback aus Typ-Definition
    const systemMoves = system.moves ?? [];
    const moves = systemMoves.length > 0
      ? systemMoves
      : (typeDef?.moves?.map(m => ({ text: m })) ?? []);

    return {
      ...data,
      system,
      dinoTypeOptions,
      selectedType,
      typeDef,
      moves,
      gimmicks: DINO_GIMMICKS
    };
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.isEditable) return;

    // Typ wechseln → Vorschlagsdaten laden
    html.find(".efdi-dino-type-select").on("change", async (ev) => {
      await this._onTypeChange(ev.currentTarget.value);
    });

    // Move hinzufügen
    html.find(".efdi-dino-move-add").on("click", async () => {
      const moves = this._getMoves();
      moves.push({ text: "" });
      await this._saveMoves(moves);
    });

    // Move löschen
    html.find(".efdi-dino-move-del").on("click", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const moves = this._getMoves();
      moves.splice(idx, 1);
      await this._saveMoves(moves);
    });

    // Move Text speichern
    html.find(".efdi-dino-move-input").on("change", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const moves = this._getMoves();
      moves[idx].text = ev.currentTarget.value;
      await this._saveMoves(moves);
    });

    // Gimmick aus Zufallsliste
    html.find(".efdi-gimmick-random").on("click", async () => {
      const g = DINO_GIMMICKS[Math.floor(Math.random() * DINO_GIMMICKS.length)];
      await this.actor.update({ "system.gimmick": g });
    });
  }

  _getMoves() {
    return foundry.utils.duplicate(this.actor.system.moves ?? []);
  }

  async _saveMoves(moves) {
    // Foundry V14: Array als JSON-String speichern dann parsen
    await this.actor.update({ "system.moves": moves });
  }

  async _onTypeChange(typeId) {
    const typeDef = DINO_TYPES[typeId];
    if (!typeDef) return;

    await this.actor.update({
      "system.dinoType": typeId,
      "system.appearing": typeDef.appearing,
      "system.instinct": typeDef.instinct,
      "system.moves": typeDef.moves.map(m => ({ text: m }))
    });
  }
}
