// scripts/sheets/npcSheet.mjs

export class EfdiNpcSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["efdi", "sheet", "actor", "npc"],
      template: "systems/escape-from-dino-island/templates/actors/npc-sheet.hbs",
      width: 480,
      height: 420,
      resizable: true
    });
  }

  async getData() {
    const data = await super.getData();
    const goalOptions = [
      "Zu einem geliebten Menschen gelangen",
      "Bleib, bis alles vorbeigeht",
      "Dinosaurier vermeiden",
      "Rache nehmen",
      "In bar bezahlt werden",
      "Niemand kann gehen",
      "Daten sichern",
      "Forschung abschließen",
      "Alles wieder normalisieren",
      "Geheimnis schützen"
    ];
    const offerOptions = [
      "Zugang zu einem Bereich",
      "Führung",
      "Waffe",
      "Dinosaurier-Wissen",
      "Cache-Wissen",
      "Fahrzeugkenntnisse",
      "Technisches System-Wissen",
      "Medizinische Versorgung"
    ];
    return { ...data, goalOptions, offerOptions };
  }

  activateListeners(html) {
    super.activateListeners(html);
  }
}
