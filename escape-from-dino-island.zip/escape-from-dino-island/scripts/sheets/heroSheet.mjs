// scripts/sheets/heroSheet.mjs
import { PLAYBOOKS, BASIC_MOVES } from "../playbookData.mjs";
import { rollStat, rollMove } from "../efdi.mjs";

export class EfdiHeroSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["efdi", "sheet", "actor", "hero"],
      template: "systems/escape-from-dino-island/templates/actors/hero-sheet.hbs",
      width: 720,
      height: 680,
      resizable: true
    });
  }

  async getData() {
    const data = await super.getData();
    const system = this.actor.system;

    const playbookId = system.playbook ?? null;
    const playbookDef = playbookId ? PLAYBOOKS[playbookId] : null;

    // Stats
    const stats = {};
    for (const stat of ["clever", "fit", "steady"]) {
      const val = system.stats?.[stat] ?? 0;
      stats[stat] = {
        value: val,
        label: game.i18n.localize(`EFDI.Stats.${stat}`),
        display: val > 0 ? `+${val}` : `${val}`
      };
    }

    const allPlaybooks = Object.entries(PLAYBOOKS).map(([id, pb]) => ({
      id,
      label: game.i18n.localize(pb.label)
    }));

    const perilMoves = BASIC_MOVES.peril.map(m => ({
      ...m,
      statLabel: m.stat && m.stat !== "none" && m.stat !== "any"
        ? game.i18n.localize(`EFDI.Stats.${m.stat}`)
        : m.stat === "any" ? "beliebig" : null
    }));
    const safetyMoves = BASIC_MOVES.safety.map(m => ({
      ...m,
      statLabel: m.stat ? game.i18n.localize(`EFDI.Stats.${m.stat}`) : null
    }));

    // Spezial-Moves: immer aus Playbook-Definition lesen
    const specialMoves = playbookDef?.specialMoves ?? [];
    const advanceMoves = playbookDef?.advanceMoves ?? [];

    const unlockedAdvances = system.unlockedAdvances ?? {};
    const advanceMovesWithState = advanceMoves.map(m => ({
      ...m,
      unlocked: unlockedAdvances[m.id] ?? false
    }));

    const injuries = {
      injury1: system.injuries?.injury1 ?? { text: "", treated: false },
      injury2: system.injuries?.injury2 ?? { text: "", treated: false },
      outOfCommission: system.injuries?.outOfCommission ?? false
    };

    // Gear: Playbook-Fallback wenn keine echten Einträge vorhanden
    const systemGear = system.gear ?? [];
    const hasRealGear = systemGear.some(g => g.name && g.name.trim() !== "");
    const gear = hasRealGear
      ? systemGear
      : (playbookDef?.gear?.map(g => ({ name: g.name, carried: g.carried ?? true })) ?? []);

    // Stories: Playbook-Fallback wenn keine echten Einträge vorhanden
    const systemStories = system.stories ?? [];
    const hasRealStories = systemStories.some(s => s.text && s.text.trim() !== "");
    const stories = hasRealStories
      ? systemStories
      : (playbookDef?.stories?.map(s => ({ text: s, told: false })) ?? []);

    const rollBonus = system.rollBonus ?? 0;

    return {
      ...data,
      system,
      stats,
      allPlaybooks,
      playbookId,
      playbookDef,
      perilMoves,
      safetyMoves,
      specialMoves,
      advanceMovesWithState,
      injuries,
      gear,
      stories,
      rollBonus,
      hasAge: playbookDef?.hasAge ?? false,
      hasHovel: playbookDef?.hasHovel ?? false,
      playbookLabel: playbookDef ? game.i18n.localize(playbookDef.label) : null
    };
  }

  activateListeners(html) {
    super.activateListeners(html);

    // ── Manuelles Tab-System ──
    const tabs = html.find(".efdi-tab");
    const panels = html.find(".efdi-tab-panel");

    // Ersten Tab aktivieren falls keiner aktiv
    if (!tabs.filter(".active").length) {
      tabs.first().addClass("active");
      panels.first().addClass("active");
    }

    tabs.on("click", (ev) => {
      const target = ev.currentTarget.dataset.tab;
      tabs.removeClass("active");
      panels.removeClass("active");
      $(ev.currentTarget).addClass("active");
      panels.filter(`[data-tab="${target}"]`).addClass("active");
    });

    if (!this.isEditable) return;

    // Playbook-Auswahl
    html.find(".efdi-playbook-select").on("change", (ev) => {
      this._onPlaybookChange(ev.currentTarget.value);
    });

    // Stat würfeln
    html.find(".efdi-roll-stat").on("click", (ev) => {
      rollStat(ev.currentTarget.dataset.stat, this.actor.id);
    });

    // Manöver würfeln
    html.find(".efdi-roll-move").on("click", (ev) => {
      rollMove(ev.currentTarget.dataset.moveId, this.actor.id);
    });

    // Advance freischalten
    html.find(".efdi-unlock-advance").on("click", async (ev) => {
      const moveId = ev.currentTarget.dataset.moveId;
      const current = foundry.utils.duplicate(this.actor.system.unlockedAdvances ?? {});
      current[moveId] = !current[moveId];
      await this.actor.update({ "system.unlockedAdvances": current });
    });

    // Verletzungen
    html.find(".efdi-injury-treated").on("change", async (ev) => {
      const field = ev.currentTarget.dataset.field;
      await this.actor.update({ [`system.injuries.${field}`]: ev.currentTarget.checked });
    });

    html.find(".efdi-out-of-commission").on("change", async (ev) => {
      await this.actor.update({ "system.injuries.outOfCommission": ev.currentTarget.checked });
    });

    html.find(".efdi-injury-text").on("blur", async (ev) => {
      const field = ev.currentTarget.dataset.field;
      await this.actor.update({ [`system.injuries.${field}.text`]: ev.currentTarget.value });
    });

    // Gear
    html.find(".efdi-gear-carried").on("change", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const gear = foundry.utils.duplicate(this.actor.system.gear ?? []);
      gear[idx].carried = ev.currentTarget.checked;
      await this.actor.update({ "system.gear": gear });
    });

    html.find(".efdi-add-gear").on("click", async () => {
      const gear = foundry.utils.duplicate(this.actor.system.gear ?? []);
      gear.push({ name: "Neuer Gegenstand", carried: true });
      await this.actor.update({ "system.gear": gear });
    });

    html.find(".efdi-delete-gear").on("click", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const gear = foundry.utils.duplicate(this.actor.system.gear ?? []);
      gear.splice(idx, 1);
      await this.actor.update({ "system.gear": gear });
    });

    html.find(".efdi-gear-name").on("change", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const gear = foundry.utils.duplicate(this.actor.system.gear ?? []);
      gear[idx].name = ev.currentTarget.value;
      await this.actor.update({ "system.gear": gear });
    });

    // Stories
    html.find(".efdi-story-told").on("change", async (ev) => {
      const idx = parseInt(ev.currentTarget.dataset.idx);
      const stories = foundry.utils.duplicate(this.actor.system.stories ?? []);
      stories[idx].told = ev.currentTarget.checked;
      await this.actor.update({ "system.stories": stories });
    });

    // Roll-Bonus
    html.find(".efdi-roll-bonus").on("change", async (ev) => {
      await this.actor.update({ "system.rollBonus": parseInt(ev.currentTarget.value) || 0 });
    });

    // Stats
    html.find(".efdi-stat-input").on("change", async (ev) => {
      const stat = ev.currentTarget.dataset.stat;
      const val = parseInt(ev.currentTarget.value) || 0;
      await this.actor.update({ [`system.stats.${stat}`]: val });
    });
  }

  async _onPlaybookChange(playbookId) {
    const pb = PLAYBOOKS[playbookId];
    if (!pb) return;

    // Erst alles leeren, dann neu setzen (Foundry V14)
    await this.actor.update({
      "system.gear": [],
      "system.stories": []
    });

    // Stats einzeln setzen
    const stats = { clever: 0, fit: 0, steady: 0 };
    if (pb.stats) Object.assign(stats, pb.stats);

    const gear = pb.gear
      ? pb.gear.map(g => ({ name: g.name, carried: g.carried ?? true }))
      : [];

    const stories = pb.stories
      ? pb.stories.map(s => ({ text: s, told: false }))
      : [];

    await this.actor.update({
      "system.playbook": playbookId,
      "system.unlockedAdvances": {},
      "system.rollBonus": 0,
      "system.stats.clever": stats.clever,
      "system.stats.fit": stats.fit,
      "system.stats.steady": stats.steady,
      "system.gear": gear,
      "system.stories": stories
    });

    // Sheet neu rendern damit alles sichtbar wird
    this.render(true);
  }
}
