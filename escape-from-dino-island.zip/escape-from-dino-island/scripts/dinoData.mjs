// scripts/dinoData.mjs
// Alle Dinosaurier-Typen mit Moves aus dem Regelwerk

export const DINO_TYPES = {
  aquatic: {
    label: "Aquatische Kreaturen",
    appearing: "1",
    instinct: "Frisst alles im Wasser",
    moves: ["Aus der Tiefe angreifen", "In die Tiefe ziehen"]
  },
  ankylosaurid: {
    label: "Ankylosauriden",
    appearing: "Einzeln (außer zur Paarungszeit)",
    instinct: "Bleib stehen",
    moves: ["Schwanzkeule", "Einen verheerenden Schlag abschütteln", "Sich ducken und sich weigern zu bewegen"]
  },
  ceratopsid: {
    label: "Ceratopsiden",
    appearing: "Eine Familieneinheit",
    instinct: "Schütze die Jungen",
    moves: ["Trampeln", "Mit Hörnern aufspießen", "Anstürmen"]
  },
  dromaeosaurid: {
    label: "Dromaeosauriden",
    appearing: "3–5",
    instinct: "Jage Beute",
    moves: ["Als Rudel arbeiten", "Mit erstaunlicher Geschwindigkeit bewegen", "Ein komplexes Problem lösen", "Mit rasiermesserscharfen Klauen aufschlitzen"]
  },
  hadrosaur: {
    label: "Hadrosauriden",
    appearing: "5–15",
    instinct: "Vermeide Raubtiere",
    moves: ["Erschrecken", "Stampede"]
  },
  ornithomimid: {
    label: "Ornithomimiden",
    appearing: "15–20",
    instinct: "Vor Raubtieren fliehen",
    moves: ["Stampede!", "Auf flinken Füßen entkommen", "Als Herde bewegen"]
  },
  pachycephalosaurid: {
    label: "Pachyzephalosauriden",
    appearing: "2–4",
    instinct: "Dominanz behaupten",
    moves: ["Kopfstoß", "Etablierte Hierarchie akzeptieren", "Etwas Wichtiges zertrümmern"]
  },
  pterosaur: {
    label: "Pterosaurier",
    appearing: "Ein Schwarm von Dutzenden",
    instinct: "Schnapp dir Futter",
    moves: ["Von oben angreifen", "Etwas wegtragen", "Etwas aus großer Höhe fallen lassen"]
  },
  sauropod: {
    label: "Sauropoden",
    appearing: "1 oder eine Herde",
    instinct: "Von den Baumwipfeln fressen",
    moves: ["Etwas umwerfen", "Herumstampfen, oblivious gegenüber kleinen Kreaturen", "Mit dem mächtigen Schwanz peitschen"]
  },
  smallTheropod: {
    label: "Kleine Theropoden",
    appearing: "Erst 1–2, dann zu viele zum Zählen",
    instinct: "Größere Beute erlegen",
    moves: ["Den Schwarm rufen", "Mit Zahlen überwältigen", "Durch winzige Passagen eintreten oder entkommen"]
  },
  spinosaurid: {
    label: "Spinosauriden",
    appearing: "1",
    instinct: "Leichte Beute aufgreifen",
    moves: ["Aus dem Wasser auftauchen", "Ins Wasser zurückziehen", "Mit mächtigen Kiefern zubeißen", "Festhalten"]
  },
  stegosaurid: {
    label: "Stegosauriden",
    appearing: "Eine große Herde",
    instinct: "Nach Futter suchen",
    moves: ["Mit einem Schwanzstachel ausschlagen", "Trampeln"]
  },
  theropod: {
    label: "Theropoden (Groß)",
    appearing: "1… oder 2 wenn du sehr Pech hast",
    instinct: "Frisst Fleisch",
    moves: ["Versteckte Beute aufspüren", "Mit immenser Kraft zubeißen", "Alles in seinem Weg zerstören", "Beute unermüdlich verfolgen"]
  },
  therizinosaur: {
    label: "Therizinosauren",
    appearing: "Eine Familieneinheit",
    instinct: "Pflanzen ernten und Territorium verteidigen",
    moves: ["Mit riesigen Klauen aufschlitzen", "Mit schweren Füßen trampeln"]
  },
  xenosaur: {
    label: "Xenosaurier",
    appearing: "???",
    instinct: "???",
    moves: ["Etwas tun, das Dinosaurier nicht können sollten"]
  }
};

export const DINO_GIMMICKS = [
  "Sehschärfe: Kann nur Bewegung wahrnehmen",
  "Giftsäcke: Hat einen giftigen Biss oder speit tödliche Toxine",
  "Gifthaut: Verursacht Schmerz, Lähmung, Blindheit oder Halluzinationen",
  "Tarnung: Kann seine Farbe ändern",
  "Intelligent: Fähig zu komplexem Problemlösen",
  "Rudeljäger: Arbeitet zusammen um Beute zu jagen",
  "Baumartig: Lebt in Bäumen",
  "Territorial: Markiert und verteidigt spezifische Grenzen",
  "Kannibalistisch: Frisst die eigene Art",
  "Mimikry: Kann Geräusche imitieren",
  "Elektrisch: Speichert und entlädt starke Entladungen",
  "Regeneration: Kann verlorene Gliedmaßen nachwachsen lassen",
  "Sonar: Jagt mit Echos von Geräuschen",
  "Klettern: Geschickt im Klettern oder klebt an Oberflächen",
  "Katzenminze: Besessen von einer modernen Substanz",
  "Fallenbauer: Baut eine natürliche Falle",
  "Schallschrei: Verletzt, desorientiert oder wirft Gegner zurück",
  "Fruchtbar: Reproduziert sich schnell",
  "Gefahrenzeichen: Signalisiert Nähe mit Rassel, Krause oder Farben",
  "Greifbar: Benutzt Schwanz oder Rüssel um Dinge zu halten"
];
