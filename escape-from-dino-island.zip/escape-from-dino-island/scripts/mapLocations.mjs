// scripts/mapLocations.mjs
// Alle Karten-Orte aus der Legende von Escape from Dino Island

export const MAP_LOCATIONS = [
  // Infrastruktur
  { id: "airstrip",         name: "Landebahn",            icon: "✈",  emoji: "✈️",  color: "#8B6914", desc: "Ein Flugstreifen – vielleicht ein Weg von der Insel?", type: "infrastructure" },
  { id: "building",         name: "Gebäude",              icon: "🏢", emoji: "🏢", color: "#6B5030", desc: "Ein Gebäude unbekannten Zwecks.", type: "infrastructure" },
  { id: "docks",            name: "Anlegesteg",           icon: "⚓", emoji: "⚓", color: "#4A6B8A", desc: "Ein Dock – Boote könnten hier anlegen.", type: "infrastructure" },
  { id: "hellpad",          name: "Hubschrauberlandeplatz", icon: "🚁", emoji: "🚁", color: "#8B6914", desc: "Ein Hubschrauberlandeplatz.", type: "infrastructure" },
  { id: "radiotower",       name: "Radioturm",            icon: "📡", emoji: "📡", color: "#8B4513", desc: "Ein Radioturm – vielleicht kann man Hilfe rufen?", type: "infrastructure" },
  { id: "laboratory",       name: "Labor",                icon: "🧪", emoji: "🧪", color: "#2E8B57", desc: "Ein wissenschaftliches Labor. Was wurde hier erforscht?", type: "infrastructure" },
  { id: "tunnel",           name: "Tunnel",               icon: "🕳",  emoji: "🕳️", color: "#5A4A3A", desc: "Ein Tunnel – wohin führt er?", type: "infrastructure" },
  { id: "fence",            name: "Zaun",                 icon: "🚧", emoji: "🚧", color: "#8B6914", desc: "Ein Zaun – elektrisch oder ausgefallen?", type: "infrastructure" },
  { id: "ruins",            name: "Ruinen",               icon: "🏛",  emoji: "🏛️", color: "#7A6A5A", desc: "Alte Ruinen – was geschah hier?", type: "landmark" },

  // Natur
  { id: "beach",            name: "Strand",               icon: "🏖",  emoji: "🏖️", color: "#D4A017", desc: "Ein Strand – vielleicht mit Wrackteilen oder Spuren.", type: "nature" },
  { id: "cliffs",           name: "Klippen",              icon: "⛰",  emoji: "⛰️", color: "#6B6B6B", desc: "Steile Klippen. Gefährlich zu erklimmen.", type: "nature" },
  { id: "forest",           name: "Wald",                 icon: "🌲", emoji: "🌲", color: "#2D5A1B", desc: "Dichter Dschungel – voller Leben und Gefahr.", type: "nature" },
  { id: "grass",            name: "Grasland",             icon: "🌿", emoji: "🌿", color: "#4A8A2A", desc: "Offenes Grasland. Wenig Deckung.", type: "nature" },
  { id: "lake",             name: "See",                  icon: "💧", emoji: "💧", color: "#4A7AAA", desc: "Ein See – was lauert unter der Oberfläche?", type: "nature" },
  { id: "mountain",         name: "Berg",                 icon: "🏔",  emoji: "🏔️", color: "#8B8B8B", desc: "Ein Berg – mit Aussichtspunkt über die Insel.", type: "nature" },
  { id: "nest",             name: "Nest",                 icon: "🥚", emoji: "🥚", color: "#8B6914", desc: "Ein Dinosauriernest. Sehr gefährlich.", type: "nature" },
  { id: "river",            name: "Fluss",                icon: "🌊", emoji: "🌊", color: "#4A7AAA", desc: "Ein reißender Fluss.", type: "nature" },
  { id: "swamp",            name: "Sumpf",                icon: "🌫",  emoji: "🌫️", color: "#4A6B4A", desc: "Ein undurchdringlicher Sumpf. Treibsand möglich.", type: "nature" },
  { id: "volcano",          name: "Vulkan",               icon: "🌋", emoji: "🌋", color: "#8B2020", desc: "Der Vulkan. Brodelt er? Könnte ausbrechen.", type: "nature" },

  // Besondere Orte
  { id: "hatchery",         name: "Brutanlage",           icon: "🔬", emoji: "🔬", color: "#2E8B57", desc: "Hier werden Dinosaurier ausgebrütet.", type: "special" },
  { id: "native_settlement",name: "Einheimischensiedlung", icon: "🏕",  emoji: "🏕️", color: "#8B6914", desc: "Eine Siedlung – wer lebt hier?", type: "special" },
  { id: "temporal_anomaly", name: "Zeitanomalie",         icon: "🌀", emoji: "🌀", color: "#7B2FBE", desc: "Eine Zeitanomalie. Violette Wolken. Seltsam.", type: "special" },
  { id: "aviary",           name: "Voliere",              icon: "🦅", emoji: "🦅", color: "#5A4A8A", desc: "Eine riesige Vogelvoliere. Pterosaurier!", type: "special" },
  { id: "road",             name: "Straße",               icon: "🛣",  emoji: "🛣️", color: "#6B6B6B", desc: "Eine Straße oder ein Pfad.", type: "infrastructure" },

  // Spieler-Markierungen
  { id: "hovel",            name: "Unterschlupf",         icon: "🏠", emoji: "🏠", color: "#8B6914", desc: "Ein Unterschlupf – Heimat des Überlebenden.", type: "player" },
  { id: "escape_route",     name: "Fluchtweg",            icon: "⭐", emoji: "⭐", color: "#D4A017", desc: "Der geplante Fluchtweg von der Insel.", type: "player" },
  { id: "danger",           name: "Gefahr",               icon: "⚠",  emoji: "⚠️", color: "#8B2020", desc: "Hier lauert Gefahr!", type: "player" },
  { id: "mystery",          name: "Geheimnis",            icon: "❓", emoji: "❓", color: "#7B2FBE", desc: "Hier gibt es ein Geheimnis zu lösen.", type: "player" },
  { id: "safe_zone",        name: "Sichere Zone",         icon: "✅", emoji: "✅", color: "#2E8B57", desc: "Hier sind die Helden (vorübergehend) sicher.", type: "player" }
];

export const LOCATION_TYPES = {
  infrastructure: { label: "Infrastruktur", color: "#8B6914" },
  nature:         { label: "Natur",         color: "#2D5A1B" },
  special:        { label: "Besondere Orte", color: "#7B2FBE" },
  player:         { label: "Spieler-Marker", color: "#D4A017" },
  landmark:       { label: "Wahrzeichen",    color: "#6B6B6B" }
};
